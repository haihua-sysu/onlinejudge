#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/times.h>
#include <sys/wait.h>

#define MAXLEN 256 
#define DEBUG

#define transfromTime(t) (t.tv_sec*1000 + t.tv_usec/1000)

int judge(char *filepath, char *filename, char *inputfile, char *outputfile, char *stdoutputfile, char *time_limit, int firstCase){
	char cmd[MAXLEN];
	pid_t pid;
	int status;
	if (firstCase){
		if ((pid=fork())<0){
			puts("fork error in compile");
			return 1;
		} else if (!pid){
			execl("/home/acfast/OJ/core/judge_compile","judge_compile",filepath,filename,"C++",NULL);
			exit(0);
		} else{
			wait(&status);
			char cefile[MAXLEN];
			sprintf(cefile,"%s%s",filepath,"CE.ERROR");
			if (access(cefile,F_OK)!=-1){
				sprintf(cmd,"%s%s","rm -f ",cefile);
				system(cmd);
				puts("Compile Error");
				return 0;
			}
		}
	}

	if ((pid=fork())<0){
		puts("fork error in running");
		return 1;
	} else if (!pid){
		execl("/home/acfast/OJ/core/judge_run","judge_run",filepath,"Main",inputfile,outputfile,time_limit,NULL);
		exit(0);
	} else{
		struct rusage resource_info;
		wait4(pid,&status,0,&resource_info);
		int time_usage=transfromTime(resource_info.ru_utime)+transfromTime(resource_info.ru_stime);
		if (WIFSIGNALED(status)){
			if (WTERMSIG(status) == SIGXCPU){
				printf("testCase %s : RunTime:%d ms Time Limit Execced\n",inputfile,time_usage);
			} else {
				printf("testCase %s : RunTime:%d ms Run Time Error\n",inputfile,time_usage);
			}
			return 0;
		}
		char user_output_file[MAXLEN],std_output_file[MAXLEN];
		sprintf(std_output_file,"%s%s",filepath,stdoutputfile);
		sprintf(user_output_file,"%s%s",filepath,outputfile);
		if (access(user_output_file, F_OK)==-1){
			printf("testCase %s : User output file not found\n",inputfile);
			return 0;
		}
		if (access(std_output_file, F_OK)==1){
			printf("testCase %s : Standard output file not found\n",inputfile);
			return 0;
	}
		sprintf(cmd, "diff --strip-trailing-cr -Z -B -w %s %s >/dev/null 2>&1\n", user_output_file, std_output_file);
		status = system(cmd);
		printf("testCase %s : RunTime:%d ms ",inputfile,time_usage);
		if (status == 0) puts("Accepted"); else puts("Wrong Answer");
	}
	return 0;
}

int main(){
	freopen("testcase.in","r",stdin);
	char filepath[MAXLEN],filename[MAXLEN],inputfile[MAXLEN],outputfile[MAXLEN],stdoutputfile[MAXLEN],time_limit[MAXLEN];
	int total=0;
	while (scanf("%s %s %s %s %s %s",filepath,filename,inputfile,outputfile,stdoutputfile,time_limit) != EOF){
		if (!total){
			judge(filepath,filename,inputfile,outputfile,stdoutputfile,time_limit,1);
		} else{
			judge(filepath,filename,inputfile,outputfile,stdoutputfile,time_limit,0);
		}
		++total;
	}
	return 0;
}
