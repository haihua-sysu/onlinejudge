#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/resource.h>
#include <string>

using std::string;

/*
 * argv[1] for filepath
 * argv[2] for filename
 * argv[3] for input file
 * argv[4] for output file
 * argv[5] for Time Limit
*/

int main(int argc, char **argv){
	if (argc != 6){
		puts("Usage: ./judge_run filepath filename inputfile outputfile time_limit");
		return 1;
	}
	string filepath(argv[1]),filename(argv[2]),inputfile(argv[3]),outputfile(argv[4]);
#ifdef DEBUG
	printf("%s %s %s %s %s %d\n",argv[1],argv[2],argv[3],argv[4],argv[5]);
#endif
	int time_limit = atoi(argv[5]);
	
	chdir(filepath.c_str());

	int fd_input = open(inputfile.c_str(), O_RDONLY);
	int fd_output = open(outputfile.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
	int fd_error = open("/dev/null",O_WRONLY);
	dup2(fd_input, STDIN_FILENO); 
	dup2(fd_output, STDOUT_FILENO);
	dup2(fd_error, STDERR_FILENO);
	close(fd_input); close(fd_output);

	struct rlimit limit;
	getrlimit(RLIMIT_CPU, &limit);
	limit.rlim_cur = (time_limit - 1)/1000+1;
	limit.rlim_max = limit.rlim_cur + 1;
	setrlimit(RLIMIT_CPU, &limit);
	
	execl(filename.c_str(),filename.c_str(),NULL);
	return 0;
}
